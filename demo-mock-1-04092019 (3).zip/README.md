# TableFilter with Webpack

This is a simple example showing how to use `TableFilter` with Webpack.

Once you cloned this repo, install and build this app with:
```
npm install
npm run build
```

Run `index.html` in your browser locally from the file system.
Inspect `index.js` in `src` directory.

